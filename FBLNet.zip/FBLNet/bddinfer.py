import numpy as np
import os
import glob
import datetime

import torch
from PIL import Image
from torch.autograd import Variable
from torchvision import transforms

from config import bdd_test
from misc import check_mkdir, crf_refine, AvgMeter, cal_precision_recall_mae, cal_fmeasure
from model import  Min_res101

torch.manual_seed(2019)

# set which gpu to use
torch.cuda.set_device(0)

# the following two args specify the location of the file of trained model (pth extension)
# you should have the pth file in the folder './$ckpt_path$/$exp_name$'
ckpt_path = './ckpt'
exp_name = 'FBLNet'

args = {
    'snapshot': 'CUHK_20000',  # your snapshot filename (exclude extension name)
    'crf_refine': False,  # whether to use crf to refine results
    'save_results': True  # whether to save the resulting masks
}

img_transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])
to_pil = transforms.ToPILImage()


to_test = {'DUT': bdd_test}



def main():
    net = Min_res101(1).cuda()

    print ('load snapshot \'%s\' for testing' % args['snapshot'])
    net.load_state_dict(torch.load(os.path.join(ckpt_path, exp_name, args['snapshot']+'.pth'), map_location='cuda:0'))  # 加载参数
    net.eval()

    results = {}

    with torch.no_grad():

            precision_record, recall_record, = [AvgMeter() for _ in range(256)], [AvgMeter() for _ in range(256)]
            mae_record = AvgMeter()

            name = 'DUT'
            root = to_test[name]
            root1 = root + '\*'
            img_roots = glob.glob(root1)
            img_roots.sort()
            if args['save_results']:
                check_mkdir(os.path.join(ckpt_path, exp_name, '(%s) %s_%s' % (exp_name, name, args['snapshot']+'_vgg16')))

            img_list = [os.path.splitext(f)[0] for f in os.listdir(root) if f.endswith('.jpg') or f.endswith('.JPG')]

            img_list.sort()
            idx = 0
            for  img_name , img_root in (zip(img_list, img_roots)):
                idx = idx+1
                print ('predicting for %s: %d / %d' % (name, idx + 1, len(img_list)))

                img = Image.open(img_root).convert('RGB')
                img_var = Variable(img_transform(img).unsqueeze(0), volatile=True).cuda()
                prediction = net(img_var)
                prediction = np.array(to_pil(prediction.data.squeeze(0).cpu()))

                if args['crf_refine']:
                    prediction = crf_refine(np.array(img), prediction)

                gt = np.array(Image.open(os.path.join(root, img_name + '.bmp').replace('DUT500S-Testing','DUT500GT-Testing')).convert('L'))
                precision, recall, mae = cal_precision_recall_mae(prediction, gt)
                for pidx, pdata in enumerate(zip(precision, recall)):
                     p, r = pdata
                     precision_record[pidx].update(p)
                     recall_record[pidx].update(r)
                mae_record.update(mae)

                if args['save_results']:
                    Image.fromarray(prediction).save(os.path.join(ckpt_path, exp_name, '(%s) %s_%s' % (
                        exp_name, name, args['snapshot']+'_vgg16'), img_name + '.png'))

            fmeasure = cal_fmeasure([precord.avg for precord in precision_record],
                                   [rrecord.avg for rrecord in recall_record])

            results[name] = {'fmeasure': fmeasure, 'mae': mae_record.avg}

    print (results)
    with open('./testlog.txt', 'a') as log:
        log.write(str(results)+'    '+'\n\n')
        log.flush()
        log.close()


if __name__ == '__main__':
    main()
