import torch
import torch.nn.functional as F
from torch import nn
import datetime
from torch.autograd import Variable

import torch
import torch.nn.functional as func
import torch.nn as nn
from torch.backends import cudnn

from resnext.resnext101 import ResNeXt101, ResNeXt102, Resnet18, Vgg16, Resnet34

## Channel Attention (CA) Layer
class CALayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(CALayer, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
                nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
                nn.PReLU(),
                nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
                nn.Sigmoid()
        )

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv_du(y)
        return x * y

class CALayer1(nn.Module):
    def __init__(self, channel, reduction=16):
        super(CALayer1, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
                nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
                nn.BatchNorm2d(channel//reduction),
                nn.PReLU(),
                nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
                nn.BatchNorm2d(channel),
                nn.Sigmoid()
        )

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv_du(y)
        return x * y


class CALayer(nn.Module):
    def __init__(self, channel, reduction=16):
        super(CALayer, self).__init__()
        # global average pooling: feature --> point
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        # feature channel downscale and upscale --> channel weight
        self.conv_du = nn.Sequential(
                nn.Conv2d(channel, channel // reduction, 1, padding=0, bias=True),
                nn.ReLU(inplace=True),
                nn.Conv2d(channel // reduction, channel, 1, padding=0, bias=True),
                nn.Sigmoid()
        )

    def forward(self, x):
        y = self.avg_pool(x)
        y = self.conv_du(y)
        return x * y

class fea_fu(nn.Module):
    def __init__(self,channel):
        super(fea_fu, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(channel, channel, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channel),
            nn.PReLU(),
            nn.Conv2d(channel, channel, kernel_size=3, padding=1, bias=True)
        )
        self.re = nn.PReLU()

    def forward(self, x):
        residual = x
        x = self.conv(x)
        out = x+residual
        return self.re(out)

class SA(nn.Module):
    def __init__(self, channel):
        super(SA, self).__init__()
        self.fai = nn.Sequential(
            nn.Conv2d(channel, 1, 1, bias=True),
            nn.Sigmoid()
        )
        self.relu4 = nn.PReLU()

    def forward(self, x, g):
        gsx = self.relu4(g + x)
        alpha = self.fai(gsx)
        return alpha * x

class MSCblock(nn.Module):
    def __init__(self,inchannel=1, channel=1):
        super(MSCblock, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(inchannel, channel, kernel_size=3,dilation=1, padding=1),
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(inchannel, channel, kernel_size=9,dilation=1, padding=4),
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(inchannel, channel, kernel_size=3,dilation=6, padding=6),
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(inchannel, channel, kernel_size=5,dilation=4, padding=8),
        )

    def forward(self, x):
        x1 = self.conv1(x)
        x2 = self.conv2(x)
        x3 = self.conv3(x)
        x4 = self.conv4(x)
        x5 = x1 + x2 + x3 +x4

        return x5

class fea_msc(nn.Module):
    def __init__(self,channel):
        super(fea_msc, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(channel, channel, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channel),
            nn.PReLU(),
        )
        self.msc = MSCblock(channel, channel)
        self.bn = nn.BatchNorm2d(channel)
        self.re = nn.PReLU()

    def forward(self, x):
        residual = x
        x = self.conv(x)
        x = self.msc(x)
        out = x+residual
        out = self.bn(out)
        return self.re(out)

class fea_msc2(nn.Module):
    def __init__(self,channel):
        super(fea_msc2, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(channel, channel, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channel),
            nn.PReLU(),
        )
        self.msc = MSCblock(1, 1)
        self.bn = nn.BatchNorm2d(1)
        self.re = nn.PReLU()

    def forward(self, x):
        residual = x
        x = self.conv(x)
        x = self.msc(x)
        out = x+residual
        out = self.bn(out)
        return self.re(out)

class sa(nn.Module):
    def __init__(self, channel):
        super(sa, self).__init__()
        self.fai = nn.Sequential(
            nn.Conv2d(channel, 1, 1, bias=True),
            nn.Sigmoid()
        )

    def forward(self, x, g):
        alpha = self.fai(g)
        return alpha * x

class sa1(nn.Module):
    def __init__(self, channel):
        super(sa1, self).__init__()
        self.fai = nn.Sequential(
            nn.Conv2d(channel, 1, 1, bias=True),
            nn.BatchNorm2d(1),
            nn.Sigmoid()
        )

    def forward(self, x, g):
        alpha = self.fai(g)
        return alpha * x


class fea_msc1(nn.Module):
    def __init__(self,channel):
        super(fea_msc1, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(channel, channel, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channel),
            nn.ReLU(),
            nn.Conv2d(channel, channel, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(channel),

        )
        self.re = nn.PReLU()

    def forward(self, x):
        residual = x
        x = self.conv(x)
        out = x+residual
        return self.re(out)

class Min_res101(torch.nn.Module):
    def __init__(self, skip_out):
        super(Min_res101, self).__init__()
        resnext = ResNeXt102()
        self.layer0 = resnext.layer0
        self.layer1 = resnext.layer1
        self.layer2 = resnext.layer2
        self.layer3 = resnext.layer3
        self.layer4 = resnext.layer4

        self.CA0 = CALayer(64)
        self.CA1 = CALayer(256)
        self.CA2 = CALayer(512)
        self.CA3 = CALayer(1024)
        self.CA4 = CALayer(2048)

        self.conv0 = nn.Conv2d(64, skip_out, kernel_size=3, padding=1, bias=True)
        self.conv1 = nn.Conv2d(256, skip_out, kernel_size=3, padding=1, bias=True)
        self.conv2 = nn.Conv2d(512, skip_out, kernel_size=3, padding=1, bias=True)
        self.conv3 = nn.Conv2d(1024, skip_out, kernel_size=3, padding=1, bias=True)
        self.conv4 = nn.Conv2d(2048, skip_out, kernel_size=3, padding=1, bias=True)

        self.fea_fu1 = fea_msc(skip_out)
        self.fea_fu2 = fea_msc(skip_out)
        self.fea_fu3 = fea_msc(skip_out)
        self.fea_fu4 = fea_msc(skip_out)

        self.SA1 = sa(skip_out)
        self.SA2 = sa(skip_out)
        self.SA3 = sa(skip_out)

        self.finalconv = fea_msc(skip_out)




    def forward(self, x):

        x_size = x.size()[2:]
        layer0 = self.layer0(x)
        layer1 = self.layer1(layer0)
        layer2 = self.layer2(layer1)
        layer3 = self.layer3(layer2)
        layer4 = self.layer4(layer3)

        l2_size = layer2.size()[2:]

        skip_4 = self.conv4(self.CA4(layer4))
        skip_3 = self.conv3(self.CA3(layer3))
        skip_2 = self.conv2(self.CA2(layer2))
        skip_1 = self.conv1(self.CA1(layer1))
        skip_0 = self.conv0(self.CA0(layer0))

        fea0 = func.interpolate(input=skip_0, size=l2_size, mode='bilinear')
        fea1 = func.interpolate(input=skip_1, size=l2_size, mode='bilinear')
        fea2 = func.interpolate(input=skip_2, size=l2_size, mode='bilinear')
        fea3 = func.interpolate(input=skip_3, size=l2_size, mode='bilinear')
        fea4 = func.interpolate(input=skip_4, size=l2_size, mode='bilinear')

        out0 = self.fea_fu1(fea2+fea3)
        out0= self.SA1(out0, out0)

        #fea1 = self.SA2(fea1, fea1)
        out1 = self.fea_fu2(out0+fea1)
        #out2 = self.SA2(out2, out2)

        out2 = self.fea_fu3(out1+fea4)
        out2 = self.SA2(out2, out2)

        #fea0 = self.SA1(fea0, fea0)
        out3 = self.fea_fu4(out2+fea0)



        out = out3+func.interpolate(input=fea0, size=l2_size, mode='bilinear')+ func.interpolate(input=fea1, size=l2_size, mode='bilinear')


        out = self.finalconv(out)
        out = self.SA3(out, out)

        out = func.interpolate(input=out, size=x_size, mode='bilinear')
        out0 = func.interpolate(input=out0, size=x_size, mode='bilinear')
        out1 = func.interpolate(input=out1, size=x_size, mode='bilinear')
        out2 = func.interpolate(input=out2, size=x_size, mode='bilinear')


        if self.training:
            return out0, out1, out2, out
        return F.sigmoid(out)

if __name__ == '__main__':
    if __name__ == '__main__':
        torch.manual_seed(2019)
        torch.cuda.set_device(0)
        cudnn.benchmark = True

        x = torch.rand(3, 320, 320)
        net = Min_res101(1).cuda()
        net = net.eval()
        x = Variable(x.unsqueeze(0), volatile=True).cuda()

        t0 = datetime.datetime.now()

        for i in range(1000):
            out = net(x)

        t1 = datetime.datetime.now()

        print(t0)
        print(t1)
        print(t1 - t0)