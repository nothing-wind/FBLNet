import datetime
import os

import torch
from torch import nn
from torch import optim
from torch.autograd import Variable
from torch.utils.data import DataLoader
from torchvision import transforms

import joint_transforms
from config import bdd_train
from datasets import bddImageFolder
from misc import AvgMeter, check_mkdir
from model import Min_res101
from torch.backends import cudnn


cudnn.benchmark = True

torch.manual_seed(2019)
torch.cuda.set_device(0)

ckpt_path = './ckpt'
exp_name = 'FBLNet_res101'

args = {
    'iter_num': 20000,  #
    'train_batch_size': 2,
    'last_iter': 0 ,
    'lr': 1e-2,
    'lr_decay': 0.9,
    'weight_decay': 5e-4,
    'momentum': 0.9,
    'snapshot': ''
}

logname = 'CUHK_%d' % args['iter_num']

joint_transform = joint_transforms.Compose([
    joint_transforms.RandomCrop(300),
    joint_transforms.RandomHorizontallyFlip(),
    joint_transforms.RandomRotate(10)
])
img_transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
])
target_transform = transforms.ToTensor()


bddtrain_set = bddImageFolder(bdd_train, joint_transform, img_transform, target_transform)
train_loader = DataLoader(bddtrain_set, batch_size=args['train_batch_size'], num_workers=0, shuffle=True)

criterion = nn.BCEWithLogitsLoss().cuda()

log_path = os.path.join(r'C:\Users\zhanggq\Desktop\FBLNet\ckpt', exp_name, logname + '.txt')  # 设定自己的存储路径


def main():
    net = Min_res101(1).cuda().train()
    #net.load_state_dict(torch.load('', map_location='cuda:0'))  #加载预训练参数
    optimizer = optim.SGD([
        {'params': [param for name, param in net.named_parameters() if name[-4:] == 'bias'],
         'lr': 2 * args['lr']},
        {'params': [param for name, param in net.named_parameters() if name[-4:] != 'bias'],
         'lr': args['lr'], 'weight_decay': args['weight_decay']}
    ], momentum=args['momentum'])

    if len(args['snapshot']) > 0:
        print( 'training resumes from ' + args['snapshot'])
        net.load_state_dict(torch.load(os.path.join(ckpt_path, exp_name, args['snapshot'] + '.pth')))
        optimizer.load_state_dict(torch.load(os.path.join(ckpt_path, exp_name, args['snapshot'] + '_optim.pth')))
        optimizer.param_groups[0]['lr'] = 2 * args['lr']
        optimizer.param_groups[1]['lr'] = args['lr']

    check_mkdir(ckpt_path)
    check_mkdir(os.path.join(ckpt_path, exp_name))
    t0 = datetime.datetime.now()
    with open(log_path, 'a') as log:
        log.write(str(args) + '\n\n')
        train(net, optimizer, log)
        log.write(str(datetime.datetime.now()-t0)+'\n')


def train(net, optimizer, log):
    curr_iter = args['last_iter']
    while True:
        total_loss_record = AvgMeter()
        loss0_record, loss1_record, loss2_record = AvgMeter(), AvgMeter(), AvgMeter()
        loss_record = AvgMeter()
        for i, data in enumerate(train_loader):
            optimizer.param_groups[0]['lr'] = 2 * args['lr'] * (1 - float(curr_iter) / args['iter_num']
                                                                ) ** args['lr_decay']
            optimizer.param_groups[1]['lr'] = args['lr'] * (1 - float(curr_iter) / args['iter_num']
                                                            ) ** args['lr_decay']

            inputs, labels = data
            batch_size = inputs.size(0)
            inputs = Variable(inputs).cuda()
            labels = Variable(labels).cuda()

            optimizer.zero_grad()
            out0, out1, out2, out = net(inputs)

            loss0 = criterion(out0, labels)
            loss1 = criterion(out1, labels)
            loss2 = criterion(out2, labels)
            loss = criterion(out, labels)

            total_loss = loss0 + loss1 + loss + loss
            total_loss.backward()
            optimizer.step()

            total_loss_record.update(total_loss.item(), batch_size)
            loss0_record.update(loss0.item(), batch_size)
            loss1_record.update(loss1.item(), batch_size)
            loss2_record.update(loss2.item(), batch_size)
            loss_record.update(loss.item(), batch_size)

            curr_iter += 1

            log1 = '[iter %d], [total loss %.5f], [loss %.5f],  [loss2 %.5f], [loss1 %.5f], [loss0 %.5f], [lr %.13f]'  % \
                   (curr_iter, total_loss_record.avg, loss_record.avg,  loss2_record.avg, loss1_record.avg,
                    loss0_record.avg,
                   optimizer.param_groups[1]['lr'])
            logWrite1 = '%d %.5f %.5f %.5f %.5f %.5f  ]' \
                  ' %.13f]' % \
                   (curr_iter, total_loss_record.avg, loss_record.avg, loss2_record.avg, loss1_record.avg,loss0_record.avg,
                   optimizer.param_groups[1]['lr'])

            print (log1)
            log.write(logWrite1 + '\n')
            log.flush()

            if curr_iter == args['iter_num']:
                torch.save(net.state_dict(), os.path.join(ckpt_path, exp_name, 'CA_%d_vgg16_DUT.pth' % curr_iter))
                torch.save(optimizer.state_dict(),
                           os.path.join(ckpt_path, exp_name, 'CA_%d_optim_vgg16_DUT.pth' % curr_iter))
                return


if __name__ == '__main__':
    main()
