# coding: utf-8
import os

bdd_train = r'E:\dataset\DefocusBlur\DUT-DBD_Dataset\DUT600S_Training'
bdd_test = r'E:\dataset\BDD\test'
